package xyz.ljcn.dao;

import java.util.List;

import xyz.ljcn.entity.Goods;



public interface GoodsDAO {

	List<Goods> query(Goods goods);

}
