package xyz.ljcn.dao;

import java.util.List;

import xyz.ljcn.entity.Orders;
import xyz.ljcn.entity.OrdersItem;



public interface OrdersDAO {

	void addOrders(Orders orders);

	void addOrdersItem(List<OrdersItem> items);

	List<Orders> query(Integer id);

	void cancel(String oid, Integer uid);

	Orders get(String oid, Integer uid);

	List<OrdersItem> getItems(String oid);

	void changeStatus(String oid, Integer uid, int status);

}
