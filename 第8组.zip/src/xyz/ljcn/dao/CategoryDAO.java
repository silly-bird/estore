package xyz.ljcn.dao;

import java.util.List;

import xyz.ljcn.entity.Category;



public interface CategoryDAO {

	List<Category> query();

}
