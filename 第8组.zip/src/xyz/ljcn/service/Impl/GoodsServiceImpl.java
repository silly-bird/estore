package xyz.ljcn.service.Impl;

import java.util.List;

import xyz.ljcn.dao.GoodsDAO;
import xyz.ljcn.entity.Goods;
import xyz.ljcn.service.GoodsService;
import xyz.ljcn.utils.BeanFactory;

public class GoodsServiceImpl implements GoodsService {

	GoodsDAO dao = BeanFactory.getBean(GoodsDAO.class);
	
	public List<Goods> query(Goods goods) {
		return dao.query(goods);
	}

}
