package xyz.ljcn.service.Impl;




import xyz.ljcn.dao.UserDao;
import xyz.ljcn.entity.User;
import xyz.ljcn.service.UserService;
import xyz.ljcn.utils.BeanFactory;
import xyz.ljcn.utils.MD5Utils;

public class UserServiceImpl implements UserService{
	UserDao dao = BeanFactory.getBean(UserDao.class);
	@Override
	public boolean checkExists(String tel) {
		return dao.checkExists(tel);
	}

	@Override
	public void register(User user) {
	
		boolean exists = dao.checkExists(user.getTelephone());
		if ( !exists ) {
			String pwd = MD5Utils.str2MD5(user.getPassword());
			user.setPassword(pwd);
			dao.register(user);
		}
	}

	@Override
	public User login(String telephone, String password) {
		password = MD5Utils.str2MD5(password);
		return dao.login(telephone, password);

  }
}