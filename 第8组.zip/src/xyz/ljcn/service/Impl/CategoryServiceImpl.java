package xyz.ljcn.service.Impl;

import java.util.List;

import xyz.ljcn.dao.CategoryDAO;
import xyz.ljcn.entity.Category;
import xyz.ljcn.service.CategoryService;
import xyz.ljcn.utils.BeanFactory;



public class CategoryServiceImpl implements CategoryService {
	CategoryDAO dao = BeanFactory.getBean(CategoryDAO.class);
	public List<Category> query() {
		return dao.query();
	}
}
