package xyz.ljcn.service.Impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import xyz.ljcn.constants.Constants;
import xyz.ljcn.dao.CartDAO;
import xyz.ljcn.dao.GoodsDAO;
import xyz.ljcn.dao.OrdersDAO;
import xyz.ljcn.entity.Cart;
import xyz.ljcn.entity.Goods;
import xyz.ljcn.entity.Orders;
import xyz.ljcn.entity.OrdersItem;
import xyz.ljcn.service.OrdersService;
import xyz.ljcn.utils.BeanFactory;
import xyz.ljcn.utils.UUIDUtils;



public class OrdersServiceImpl implements OrdersService {
	OrdersDAO dao = BeanFactory.getBean(OrdersDAO.class);
	CartDAO cartDAO = BeanFactory.getBean(CartDAO.class);
	GoodsDAO goodsDAO = BeanFactory.getBean(GoodsDAO.class);
	
	public void addOrders(Integer uid, String address) {
		// 根据已有信息，构造出订单对象
		Orders orders = new Orders();
		orders.setUid(uid);
		orders.setAddress(address);
		
		// 生成随机32位订单编号
		String id = UUIDUtils.getUUID();
		orders.setId(id);
		
		// 计算总金额
		// 查询购物车信息，包含商品信息
		Cart cart = new Cart();
		cart.setUid(uid);
		List<Cart> cList = cartDAO.queryWithGoods(cart);
		
		// 计算总金额，并构建订单明细数据
		double price = 0; // 总金额
		// 订单明细
		List<OrdersItem> items = new ArrayList<>();
		for (Cart c : cList) {
			price += c.getGoods().getEstoreprice() * c.getBuynum();
			OrdersItem item = new OrdersItem(id, c.getGid(), c.getBuynum());
			items.add(item);
		}
		orders.setTotalprice(price);
		
		// 订单状态：1待付款  2已付款 3已过期   4已取消
		orders.setStatus(Constants.STATUS_ORDER.UNPAY);
		orders.setCreatetime(new Date());
		
		// 添加订单数据
		dao.addOrders(orders);
		// 添加订单明细
		dao.addOrdersItem(items);
		// 清空购物车
		cartDAO.clear(uid);
	}
	@Override
	public List<Orders> query(Integer id) {
		
		return dao.query(id);
	}
	@Override
	public void cancel(String oid, Integer uid) {
		dao.cancel(oid, uid);
		
	}
	public Orders get(String oid, Integer uid) {
		// 查询订单
		Orders orders = dao.get(oid, uid);
		
		// 查询订单明细List
		List<OrdersItem> list = dao.getItems(oid);
		orders.setList(list);
		
		// 遍历List,查询商品信息
		Goods goods = new Goods();
		for (OrdersItem item : list) {
			goods.setId(item.getGid());
			Goods goods2 = goodsDAO.query(goods).get(0);
			item.setGoods(goods2);
		}
		
		return orders;
	}
	
	public void changeStatus(String oid, Integer uid, int status) {
		dao.changeStatus(oid, uid, status);
	}
}
