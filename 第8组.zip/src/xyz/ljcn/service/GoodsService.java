package xyz.ljcn.service;

import java.util.List;

import xyz.ljcn.entity.Goods;



public interface GoodsService {

	List<Goods> query(Goods goods);

}
