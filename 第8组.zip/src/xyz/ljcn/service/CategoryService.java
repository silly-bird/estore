package xyz.ljcn.service;

import java.util.List;

import xyz.ljcn.entity.Category;



public interface CategoryService {

	List<Category> query();

}
