package xyz.ljcn.service;

import xyz.ljcn.entity.User;

public interface UserService {
	boolean checkExists(String tel);

	void register(User user);

	User login(String telephone, String password);

}
