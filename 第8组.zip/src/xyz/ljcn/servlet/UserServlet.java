package xyz.ljcn.servlet;

import java.io.IOException;

import javax.jws.WebService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import xyz.ljcn.constants.Constants;
import xyz.ljcn.entity.User;
import xyz.ljcn.service.UserService;
import xyz.ljcn.utils.BeanFactory;

import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.exceptions.ServerException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;


@SuppressWarnings("all")
@WebServlet("/user")
public class UserServlet extends BaseServlet{
	public static void main(String[] args) {
		DefaultProfile profile = DefaultProfile.getProfile("default", "LTAIPihk73PHuXc9", "tPmn9rcvDEhU67x6Eg8I2DQIVPLPe9");
        IAcsClient client = new DefaultAcsClient(profile);

        CommonRequest request = new CommonRequest();
        //request.setProtocol(ProtocolType.HTTPS);
        request.setMethod(MethodType.POST);
        request.setDomain("dysmsapi.aliyuncs.com");
        request.setVersion("2017-05-25");
        request.setAction("SendSms");
        request.putQueryParameter("PhoneNumbers", "18105185234");
        request.putQueryParameter("SignName", "千峰商城");
        request.putQueryParameter("TemplateCode", "SMS_166096053");
        request.putQueryParameter("TemplateParam", "{\"code\":\"123456\"}");
        try {
            CommonResponse response = client.getCommonResponse(request);
            System.out.println(response.getData());
        } catch (ServerException e) {
            e.printStackTrace();
        } catch (ClientException e) {
            e.printStackTrace();
        }
	}
	
	
	UserService service = BeanFactory.getBean(UserService.class);
	
	public void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String telephone = req.getParameter("telephone");
		String password = req.getParameter("password");
		
		User user = service.login(telephone, password);
		if ( user == null ) {
			resp.getWriter().write("err");
		} else {
			
			// 将用户对象保存到session中
			req.getSession().setAttribute(Constants.USER.LOGINUSER, user);
			// 记住用户名
			String remember = req.getParameter("remember");
			if ( remember != null ) {
				Cookie c = new Cookie("telephone", telephone);
				c.setMaxAge(9999999);
				resp.addCookie(c);
			} else {
				Cookie c = new Cookie("telephone", null);
				c.setMaxAge(0);
				resp.addCookie(c);
			}
			
			resp.getWriter().write("ok");
		}
	}
	
	
	public void register(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User user = new User();
		try {
			BeanUtils.populate(user, req.getParameterMap());
			service.register(user);
			resp.sendRedirect(req.getContextPath() + "/login.jsp");
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	
	// 验证图片验证码是否正确
	public void checkIMGCode(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String imgCode1 = req.getParameter("imgCode");
		String imgCode2 = (String)req.getSession().getAttribute("code");
		if ( imgCode1 == null || "".equals(imgCode1) || !imgCode1.equalsIgnoreCase(imgCode2) ) {
			resp.getWriter().write("false");
		} else {
			resp.getWriter().write("true");
		}
	}
	
	// 验证短信验证码是否正确
	public void checkSMSCode(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String smsCode1 = req.getParameter("smsCode");
		String smsCode2 = (String)req.getSession().getAttribute("smsCode");
		if ( smsCode1 == null || "".equals(smsCode1) || !smsCode1.equalsIgnoreCase(smsCode2) ) {
			resp.getWriter().write("false");
		} else {
			resp.getWriter().write("true");
		}
	}
	
	// 验证手机号是否被注册
	public void checkExists(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String tel = req.getParameter("tel");
		boolean exists = service.checkExists(tel);
		resp.getWriter().write(exists + "");
	}
	
	public void sendSMS(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 生成6位验证码
        String code = (Math.random()+"").substring(2, 8);
        // 将验证码保存到session中，验证使用
        req.getSession().setAttribute("smsCode", code);
        System.out.println(code+"====================");
		
		
	}
}
