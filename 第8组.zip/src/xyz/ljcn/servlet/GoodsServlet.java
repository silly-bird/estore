package xyz.ljcn.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;

import xyz.ljcn.entity.Goods;
import xyz.ljcn.service.GoodsService;
import xyz.ljcn.utils.BeanFactory;



@SuppressWarnings("all")
@WebServlet("/goods")
public class GoodsServlet extends BaseServlet {
	GoodsService service = BeanFactory.getBean(GoodsService.class);
	
	public void query(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Goods goods = new Goods();
		
		try {
			BeanUtils.populate(goods, req.getParameterMap());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		List<Goods> gList = service.query(goods);
		req.setAttribute("gList", gList);
		
		if ( StringUtils.equals(req.getParameter("target"), "detail") ) {
			req.getRequestDispatcher("/goods_detail.jsp").forward(req, resp);
		} else {
			req.getRequestDispatcher("/goods.jsp").forward(req, resp);
		}
	}
}
