package xyz.ljcn.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;






import redis.clients.jedis.Jedis;
import xyz.ljcn.entity.Category;
import xyz.ljcn.service.CategoryService;
import xyz.ljcn.utils.BeanFactory;
import xyz.ljcn.utils.JedisUtils;

@SuppressWarnings("all")
@WebServlet("/category")
public class CategoryServlet extends BaseServlet {
	CategoryService service = BeanFactory.getBean(CategoryService.class);
	
	public void query(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Jedis jedis = JedisUtils.getJedis();
		String json = jedis.get("category");
		if ( json == null ) {
			List<Category> cList = service.query();
			Gson gson = new Gson();
			json = gson.toJson(cList);
			jedis.set("category", json);
		}
		JedisUtils.closeJedis(jedis);
		
		resp.getWriter().write(json);
	}
	
	public void add(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	}
}
